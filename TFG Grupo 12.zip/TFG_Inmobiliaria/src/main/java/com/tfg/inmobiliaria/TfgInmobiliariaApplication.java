package com.tfg.inmobiliaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TfgInmobiliariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TfgInmobiliariaApplication.class, args);
	}

}
