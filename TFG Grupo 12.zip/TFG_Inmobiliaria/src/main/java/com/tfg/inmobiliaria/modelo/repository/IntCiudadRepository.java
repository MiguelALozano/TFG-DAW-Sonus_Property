package com.tfg.inmobiliaria.modelo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tfg.inmobiliaria.beansentity.Ciudad;

public interface IntCiudadRepository extends JpaRepository<Ciudad, Integer>{

}
