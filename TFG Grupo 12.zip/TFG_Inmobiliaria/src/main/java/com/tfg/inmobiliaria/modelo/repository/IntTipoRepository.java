package com.tfg.inmobiliaria.modelo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tfg.inmobiliaria.beansentity.Tipo;

public interface IntTipoRepository extends JpaRepository<Tipo, Integer>{

}
