package com.tfg.inmobiliaria.modelo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tfg.inmobiliaria.beansentity.Usuario;

public interface IntUsuarioRepository extends JpaRepository<Usuario, String>{

}
